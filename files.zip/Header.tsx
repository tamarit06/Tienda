interface HeaderProps {
  totalItems: number;
  totalPrecio: number;
  onAbrirCarrito: () => void;
}

export default function Header({ totalItems, totalPrecio, onAbrirCarrito }: HeaderProps) {
  return (
    <header className="header">
      <div className="header-marca">
        <span className="header-eyebrow">Menú del día</span>
        <h1>La Esquina</h1>
      </div>

      <button className="resumen-carrito" onClick={onAbrirCarrito}>
        <span className="resumen-carrito-cantidad">{totalItems}</span>
        <span className="resumen-carrito-texto">
          {totalItems === 1 ? "producto" : "productos"} · ${totalPrecio.toFixed(2)}
        </span>
      </button>
    </header>
  );
}

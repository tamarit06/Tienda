import { useEffect, useState } from "react";
import { obtenerCategorias, obtenerProductos } from "./api";
import type { Categoria, Producto, ItemCarrito } from "./types";
import Header from "./components/Header.tsx";
import ProductGrid from "./components/ProductGrid.tsx";
import Cart from "./components/Cart.tsx";

export default function App() {
  const [categorias, setCategorias] = useState<Categoria[]>([]);
  const [productos, setProductos] = useState<Producto[]>([]);
  const [carrito, setCarrito] = useState<ItemCarrito[]>([]);
  const [cargando, setCargando] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [carritoAbierto, setCarritoAbierto] = useState(false);

  useEffect(() => {
    async function cargarDatos() {
      try {
        const [cats, prods] = await Promise.all([obtenerCategorias(), obtenerProductos()]);
        setCategorias(cats);
        setProductos(prods);
      } catch (err) {
        setError(err instanceof Error ? err.message : "Error desconocido");
      } finally {
        setCargando(false);
      }
    }
    cargarDatos();
  }, []);

  function agregarAlCarrito(producto: Producto) {
    setCarrito((actual) => {
      const existente = actual.find((item) => item.producto.id === producto.id);
      if (existente) {
        return actual.map((item) =>
          item.producto.id === producto.id ? { ...item, cantidad: item.cantidad + 1 } : item
        );
      }
      return [...actual, { producto, cantidad: 1 }];
    });
  }

  function cambiarCantidad(productoId: number, delta: number) {
    setCarrito((actual) =>
      actual
        .map((item) =>
          item.producto.id === productoId ? { ...item, cantidad: item.cantidad + delta } : item
        )
        .filter((item) => item.cantidad > 0)
    );
  }

  function quitarDelCarrito(productoId: number) {
    setCarrito((actual) => actual.filter((item) => item.producto.id !== productoId));
  }

  const totalItems = carrito.reduce((suma, item) => suma + item.cantidad, 0);
  const totalPrecio = carrito.reduce((suma, item) => suma + item.producto.precio * item.cantidad, 0);

  return (
    <div className="pagina">
      <Header
        totalItems={totalItems}
        totalPrecio={totalPrecio}
        onAbrirCarrito={() => setCarritoAbierto(true)}
      />

      <main className="contenido">
        {cargando && <p className="estado-info">Cargando el menú...</p>}
        {error && (
          <p className="estado-error">
            {error}. Revisá que el backend esté corriendo en <code>localhost:8000</code>.
          </p>
        )}
        {!cargando && !error && (
          <ProductGrid categorias={categorias} productos={productos} onAgregar={agregarAlCarrito} />
        )}
      </main>

      <Cart
        items={carrito}
        total={totalPrecio}
        abierto={carritoAbierto}
        onCerrar={() => setCarritoAbierto(false)}
        onCambiarCantidad={cambiarCantidad}
        onQuitar={quitarDelCarrito}
      />
    </div>
  );
}

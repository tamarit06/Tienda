import type { Categoria, Producto } from "../types";
import ProductCard from "./ProductCard.tsx";

interface ProductGridProps {
  categorias: Categoria[];
  productos: Producto[];
  onAgregar: (producto: Producto) => void;
}

export default function ProductGrid({ categorias, productos, onAgregar }: ProductGridProps) {
  const sinCategoria = productos.filter((p) => !p.categoria_id);

  return (
    <div className="grilla-categorias">
      {categorias.map((categoria) => {
        const productosDeCategoria = productos.filter((p) => p.categoria_id === categoria.id);
        if (productosDeCategoria.length === 0) return null;

        return (
          <section key={categoria.id} className="seccion-categoria">
            <h2>{categoria.nombre}</h2>
            <div className="grilla-productos">
              {productosDeCategoria.map((producto) => (
                <ProductCard key={producto.id} producto={producto} onAgregar={onAgregar} />
              ))}
            </div>
          </section>
        );
      })}

      {sinCategoria.length > 0 && (
        <section className="seccion-categoria">
          <h2>Otros</h2>
          <div className="grilla-productos">
            {sinCategoria.map((producto) => (
              <ProductCard key={producto.id} producto={producto} onAgregar={onAgregar} />
            ))}
          </div>
        </section>
      )}

      {categorias.length === 0 && productos.length === 0 && (
        <p className="estado-info">Todavía no hay productos cargados en el backend.</p>
      )}
    </div>
  );
}

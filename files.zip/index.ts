export interface Categoria {
  id: number;
  nombre: string;
}

export interface Producto {
  id: number;
  nombre: string;
  descripcion: string | null;
  precio: number;
  disponible: boolean;
  categoria_id: number | null;
}

export interface ItemCarrito {
  producto: Producto;
  cantidad: number;
}
